package com.example.soccergamesfinder.ui.screens

import android.content.Intent
import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.autofill.AutofillType
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.soccergamesfinder.viewmodel.AuthViewModel
import com.example.soccergamesfinder.viewmodel.UserViewModel

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun LoginScreen(
    authViewModel: AuthViewModel,
    userViewModel: UserViewModel,
    navigateToHome: () -> Unit,
    navigateToRegister: () -> Unit,
    navigateToCompleteProfile: () -> Unit,
    launchGoogleSignIn: (Intent) -> Unit
) {
    val email = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val errorMessage by authViewModel.errorMessage
    val currentUser = authViewModel.user.value

    LaunchedEffect(currentUser) {
        if (currentUser != null) {
            userViewModel.fetchUserProfile()
        }
    }

    LaunchedEffect(userViewModel.isProfileLoaded.value) {
        if (userViewModel.isProfileLoaded.value) {
            if (userViewModel.firstName.value.isNullOrBlank()) {
                navigateToCompleteProfile()
            } else {
                navigateToHome()
            }
            userViewModel.isProfileLoaded.value = false
        }
    }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = email.value,
            onValueChange = { email.value = it },
            label = { Text("אימייל") }
        )
        TextField(
            value = password.value,
            onValueChange = { password.value = it },
            label = { Text("סיסמה") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password),
            visualTransformation = PasswordVisualTransformation()
        )

        if (errorMessage != null) {
            Text(text = errorMessage!!, color = Color.Red)
        }

        Button(onClick = { authViewModel.login(email.value, password.value) }) {
            Text("התחבר")
        }

        Button(onClick = navigateToRegister) {
            Text("אין לך חשבון? הירשם כאן")
        }

        Button(onClick = { launchGoogleSignIn(authViewModel.getGoogleSignInIntent()) }) {
            Text("התחברות עם Google")
        }
    }
}

package com.example.soccergamesfinder.viewmodel

import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.soccergamesfinder.repository.UserRepository
import kotlinx.coroutines.launch

class UserViewModel(application: Application) : AndroidViewModel(application) {

    private val userRepository = UserRepository.getInstance()

    var firstName = mutableStateOf<String?>(null)
        private set
    var lastName = mutableStateOf<String?>(null)
        private set
    var age = mutableStateOf<Int?>(null)
        private set
    var location = mutableStateOf<String?>(null)
        private set
    var profileImageUrl = mutableStateOf<String?>(null)
        private set
    var nickname = mutableStateOf<String?>(null)
        private set

    var errorMessage = mutableStateOf<String?>(null)
        private set

    var isProfileLoaded = mutableStateOf(false)


    fun fetchUserProfile() {
        viewModelScope.launch {
            isProfileLoaded.value = false
            val data = userRepository.getUserProfile()
            if (data != null) {
                firstName.value = data["firstName"] as? String
                lastName.value = data["lastName"] as? String
                age.value = (data["age"] as? Long)?.toInt()
                location.value = data["location"] as? String
                profileImageUrl.value = data["profileImageUrl"] as? String
                nickname.value = data["nickname"] as? String
                errorMessage.value = null
            }
            isProfileLoaded.value = true
        }
    }

    fun updateUserProfile(
        firstName: String,
        lastName: String,
        age: Int,
        coordinates: String,
        profileImageUrl: String,
        nickname: String,
        onResult: (Boolean) -> Unit
    ) {
        viewModelScope.launch {

            val currentUserId = userRepository.getCurrentUserId()
            if (userRepository.isNicknameTaken(nickname, currentUserId)) {
                errorMessage.value = "הכינוי כבר בשימוש"
                onResult(false)
                return@launch
            }


            val profileData = mapOf(
                "firstName" to firstName,
                "lastName" to lastName,
                "age" to age,
                "location" to coordinates,
                "profileImageUrl" to profileImageUrl,
                "nickname" to nickname
            )

            val success = userRepository.updateUserProfile(profileData)
            if (success) {
                this@UserViewModel.firstName.value = firstName
                this@UserViewModel.lastName.value = lastName
                this@UserViewModel.age.value = age
                this@UserViewModel.location.value = coordinates
                this@UserViewModel.profileImageUrl.value = profileImageUrl
                this@UserViewModel.nickname.value = nickname
                errorMessage.value = null
                onResult(true)
            } else {
                errorMessage.value = "שגיאה בעדכון הפרופיל"
            }
        }
    }

    fun clearProfileState() {
        firstName.value = null
        lastName.value = null
        age.value = null
        location.value = null
        profileImageUrl.value = null
        nickname.value = null
        errorMessage.value = null
        isProfileLoaded.value = false
    }

}

package com.example.soccergamesfinder.utils

import android.content.Context
import android.location.Geocoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.Locale

object GeocodingUtils {

    /**
     * ממיר קואורדינטות (latitude, longitude) לכתובת מלאה.
     * הפונקציה רצה על רקע (background thread) באמצעות Coroutine.
     *
     * @param context Context – דרוש ליצירת ה-Geocoder.
     * @param latitude קו רוחב.
     * @param longitude קו אורך.
     * @return כתובת מלאה כמחרוזת, או null אם לא נמצאה כתובת.
     */
    suspend fun getAddressFromCoordinates(
        context: Context,
        latitude: Double,
        longitude: Double
    ): String? = withContext(Dispatchers.IO) {
        val geocoder = Geocoder(context, Locale.getDefault())
        try {
            val addresses = geocoder.getFromLocation(latitude, longitude, 1)
            if (!addresses.isNullOrEmpty()) {
                addresses[0].getAddressLine(0)
            } else {
                null
            }
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    /**
     * ממיר כתובת (כתובת מלאה) לקואורדינטות.
     * הפונקציה רצה על רקע (background thread) באמצעות Coroutine.
     *
     * @param context Context – דרוש ליצירת ה-Geocoder.
     * @param address כתובת כמחרוזת.
     * @return זוג (Pair) של Double שמייצג (latitude, longitude) או null אם לא נמצאו קואורדינטות.
     */
    suspend fun getCoordinatesFromAddress(
        context: Context,
        address: String
    ): Pair<Double, Double>? = withContext(Dispatchers.IO) {
        val geocoder = Geocoder(context, Locale.getDefault())
        try {
            val addresses = geocoder.getFromLocationName(address, 1)
            if (!addresses.isNullOrEmpty()) {
                Pair(addresses[0].latitude, addresses[0].longitude)
            } else {
                null
            }
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }
}

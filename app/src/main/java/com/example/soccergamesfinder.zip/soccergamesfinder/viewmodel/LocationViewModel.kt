package com.example.soccergamesfinder.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.location.Location
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.soccergamesfinder.utils.GeocodingUtils
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch

class LocationViewModel(application: Application) : AndroidViewModel(application) {

    var currentLocation = mutableStateOf<String?>(null)
        private set

    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(application)

    // יש לוודא שבוצעה בקשת הרשאה לפני קריאה לפונקציה זו
    @SuppressLint("MissingPermission")
    fun requestLocation() {
        currentLocation.value = null  // איפוס המיקום
        fusedLocationClient.getCurrentLocation(
            com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, null
        ).addOnSuccessListener { location ->
            location?.let {
                viewModelScope.launch {
                    val address = GeocodingUtils.getAddressFromCoordinates(getApplication(), it.latitude, it.longitude)
                    currentLocation.value = address ?: "${it.latitude}, ${it.longitude}"
                }
            }
        }
    }

}

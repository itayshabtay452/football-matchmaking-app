package com.example.soccergamesfinder

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import com.example.soccergamesfinder.navigation.AppNavigation
import com.example.soccergamesfinder.utils.PreferencesHelper
import com.example.soccergamesfinder.viewmodel.AuthViewModel
import com.example.soccergamesfinder.viewmodel.LocationViewModel
import com.example.soccergamesfinder.viewmodel.UserViewModel
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by lazy { AuthViewModel(application) }
    private val userViewModel: UserViewModel by lazy { UserViewModel(application) }
    private val locationViewModel: LocationViewModel by lazy { LocationViewModel(application) }

    // Launcher עבור Google Sign-In
    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        authViewModel.handleGoogleSignInResult(result.data)
    }

    // Launcher לבקשת הרשאת מיקום
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            locationViewModel.requestLocation()
        }
    }

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // בקשת הרשאת מיקום
        locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)

        if (!PreferencesHelper.isAutoLoginEnabled(this)) {
            FirebaseAuth.getInstance().signOut()
        }

        // בדיקה האם קיימת session של משתמש והאם המשתמש בחר להתחבר אוטומטית
        val currentUser = FirebaseAuth.getInstance().currentUser
        val autoLoginEnabled = PreferencesHelper.isAutoLoginEnabled(this)
        val startDestination = if (currentUser != null && autoLoginEnabled) "home" else "login"

        setContent {
            AppNavigation(
                authViewModel = authViewModel,
                userViewModel = userViewModel,
                locationViewModel = locationViewModel,
                launchGoogleSignIn = { intent ->
                    googleSignInLauncher.launch(intent)
                },
                startDestination = startDestination
            )
        }
    }
}

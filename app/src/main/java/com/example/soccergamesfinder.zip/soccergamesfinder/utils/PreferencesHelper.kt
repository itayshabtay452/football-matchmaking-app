package com.example.soccergamesfinder.utils

import android.content.Context
import android.content.SharedPreferences

object PreferencesHelper {
    private const val PREFS_NAME = "soccergamesfinder_prefs"
    private const val KEY_AUTO_LOGIN = "auto_login"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun setAutoLogin(context: Context, autoLogin: Boolean) {
        val editor = getPrefs(context).edit()
        editor.putBoolean(KEY_AUTO_LOGIN, autoLogin)
        editor.apply()
    }

    fun isAutoLoginEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_AUTO_LOGIN, false)
    }
}

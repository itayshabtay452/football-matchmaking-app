package com.example.soccergamesfinder.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class UserRepository private constructor() {

    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    companion object {
        @Volatile
        private var INSTANCE: UserRepository? = null

        fun getInstance(): UserRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: UserRepository().also { INSTANCE = it }
            }
        }
    }
    suspend fun getUserProfile(): Map<String, Any>? {
        val uid = auth.currentUser?.uid ?: return null
        return try {
            val document = firestore.collection("users").document(uid).get().await()
            if (document.exists()) document.data else null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun updateUserProfile(profileData: Map<String, Any>): Boolean {
        val uid = auth.currentUser?.uid ?: return false
        return try {
            firestore.collection("users").document(uid).set(profileData).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getCurrentUserId(): String? {
        return auth.currentUser?.uid
    }

    suspend fun isNicknameTaken(nickname: String, currentUserId: String?): Boolean {
        return try {
            val querySnapshot = firestore.collection("users")
                .whereEqualTo("nickname", nickname)
                .get()
                .await()
            // אם לא נמצאו מסמכים – הכינוי פנוי.
            // אם נמצאו, נבדוק אם יש מסמך ששייך למשתמש אחר.
            if (querySnapshot.isEmpty) {
                false
            } else {
                querySnapshot.documents.any { it.id != currentUserId }
            }
        } catch (e: Exception) {
            // במקרה של שגיאה, אפשר להניח שהכינוי תפוס או לטפל אחרת.
            false
        }
    }


}

package com.example.soccergamesfinder.navigation

import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.soccergamesfinder.ui.screens.CompleteProfileScreen
import com.example.soccergamesfinder.ui.screens.HomeScreen
import com.example.soccergamesfinder.ui.screens.LoginScreen
import com.example.soccergamesfinder.ui.screens.RegisterScreen
import com.example.soccergamesfinder.viewmodel.AuthViewModel
import com.example.soccergamesfinder.viewmodel.LocationViewModel
import com.example.soccergamesfinder.viewmodel.UserViewModel

@Composable
fun AppNavigation(
    authViewModel: AuthViewModel,
    userViewModel: UserViewModel,
    locationViewModel: LocationViewModel,
    launchGoogleSignIn: (Intent) -> Unit,
    startDestination: String = "login" // ברירת מחדל
) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = startDestination) {

        composable("login") {
            LoginScreen(
                authViewModel = authViewModel,
                userViewModel = userViewModel,
                navigateToHome = { navController.navigate("home") { popUpTo("login") { inclusive = true } } },
                navigateToRegister = { navController.navigate("register") },
                navigateToCompleteProfile = { navController.navigate("completeProfile") { popUpTo("login") { inclusive = true } }},
                launchGoogleSignIn = launchGoogleSignIn
            )
        }

        composable("register") {
            RegisterScreen(
                authViewModel = authViewModel,
                navigateToCompleteProfile = { navController.navigate("completeProfile") }
            )
        }

        composable("completeProfile") {
            CompleteProfileScreen(
                userViewModel = userViewModel,
                locationViewModel = locationViewModel,
                navigateToHome = {
                    userViewModel.fetchUserProfile() // לוודא שטעינת הנתונים הסתיימה
                    navController.navigate("home") { popUpTo("completeProfile") { inclusive = true } }
                }
            )
        }

        composable("home") {
            HomeScreen(
                authViewModel = authViewModel,
                userViewModel = userViewModel,
                navigateToLogin = { navController.navigate("login") { popUpTo("home") { inclusive = true } } }
            )
        }
    }
}

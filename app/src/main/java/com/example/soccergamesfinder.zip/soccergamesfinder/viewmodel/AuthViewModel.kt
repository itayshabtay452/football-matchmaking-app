package com.example.soccergamesfinder.viewmodel

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.soccergamesfinder.repository.AuthRepository
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.launch

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepository: AuthRepository = AuthRepository.getInstance(application)

    var user = mutableStateOf<FirebaseUser?>(authRepository.getCurrentUser())
        private set

    var errorMessage = mutableStateOf<String?>(null)
        private set

    fun getGoogleSignInIntent(): Intent {
        return authRepository.getGoogleSignInClient().signInIntent
    }

    fun handleGoogleSignInResult(data: Intent?) {
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        viewModelScope.launch {
            try {
                val idToken = task.getResult(com.google.android.gms.common.api.ApiException::class.java)?.idToken
                if (idToken != null) {
                    val googleUser = authRepository.signInWithGoogle(idToken)
                    if (googleUser != null) {
                        user.value = googleUser
                    } else {
                        errorMessage.value = "Google Sign-In נכשל"
                    }
                } else {
                    errorMessage.value = "Google Sign-In נכשל: לא התקבל מזהה"
                }
            } catch (e: com.google.android.gms.common.api.ApiException) {
                errorMessage.value = "Google Sign-In נכשל: ${e.message}"
            }
        }
    }

    fun register(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            errorMessage.value = "יש למלא אימייל וסיסמה"
            return
        }
        viewModelScope.launch {
            val newUser = authRepository.register(email, password)
            if (newUser != null) {
                user.value = newUser
            } else {
                errorMessage.value = "הרשמה נכשלה"
            }
        }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            errorMessage.value = "יש למלא אימייל וסיסמה"
            return
        }
        viewModelScope.launch {
            val loggedInUser = authRepository.login(email, password)
            if (loggedInUser != null) {
                user.value = loggedInUser
            } else {
                errorMessage.value = "כניסה נכשלה"
            }
        }
    }

    fun logout() {
        authRepository.logout()
        user.value = null
    }
}

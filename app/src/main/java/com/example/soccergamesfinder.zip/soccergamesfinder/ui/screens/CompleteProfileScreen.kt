package com.example.soccergamesfinder.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role.Companion.Image
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.soccergamesfinder.utils.PreferencesHelper
import com.example.soccergamesfinder.viewmodel.LocationViewModel
import com.example.soccergamesfinder.viewmodel.UserViewModel

@Composable
fun CompleteProfileScreen(
    userViewModel: UserViewModel,
    locationViewModel: LocationViewModel,
    navigateToHome: () -> Unit
) {
    val errorMessage by userViewModel.errorMessage

    var tempFirstName by remember { mutableStateOf("") }
    var tempLastName by remember { mutableStateOf("") }
    var tempAge by remember { mutableStateOf("") }
    var tempCoordinates by remember { mutableStateOf("") } // לדוגמה: "40.12345, -74.12345"
    var tempProfileImageUrl by remember { mutableStateOf("") }
    var autoLogin by remember { mutableStateOf(false) }
    var tempNickname by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }


    var firstNameError by remember { mutableStateOf<String?>(null) }
    var lastNameError by remember { mutableStateOf<String?>(null) }
    var nicknameError by remember { mutableStateOf<String?>(null) }
    var ageError by remember { mutableStateOf<String?>(null) }
    var coordinatesError by remember { mutableStateOf<String?>(null) }
    var imageError by remember { mutableStateOf<String?>(null) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        imageUri = uri
        // אם נבחרה תמונה, מאפסים הודעת שגיאה
        if (uri != null) {
            imageError = null
        }
    }

    // עדכון שדה "מיקום" כאשר LocationViewModel מעדכן את המיקום
    LaunchedEffect(locationViewModel.currentLocation.value) {
        locationViewModel.currentLocation.value?.let { address ->
            tempCoordinates = address
            coordinatesError = null
        }
    }

    val context = LocalContext.current

    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {

        ValidatedTextField(
            value = tempFirstName,
            onValueChange = {
                tempFirstName = it
                firstNameError = if (it.isBlank()) "יש להזין שם פרטי" else null
            },
            label = "שם פרטי",
            error = firstNameError
        )

        ValidatedTextField(
            value = tempLastName,
            onValueChange = {
                tempLastName = it
                lastNameError = if (it.isBlank()) "יש להזין שם משפחה" else null
            },
            label = "שם משפחה",
            error = lastNameError
        )

        ValidatedTextField(
            value = tempAge,
            onValueChange = {
                tempAge = it
                val ageInt = it.toIntOrNull()
                ageError = if (ageInt == null || ageInt <= 0) "יש להזין גיל תקין" else null
            },
            label = "גיל",
            error = ageError,
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
        )

        ValidatedTextField(
            value = tempNickname,
            onValueChange = {
                tempNickname = it
                nicknameError = if (it.isBlank()) "יש להזין כינוי" else null
            },
            label = "כינוי",
            error = nicknameError
        )

        ValidatedTextField(
            value = tempCoordinates,
            onValueChange = {
                tempCoordinates = it
                coordinatesError = if (it.isBlank()) "יש להזין מיקום" else null
            },
            label = "מיקום",
            error = coordinatesError
        )

        Button(onClick = {
            // כאן נניח שהרשאות מיקום כבר נבדקו (או שב-MainActivity ביקש אותן)
            locationViewModel.requestLocation()
        }) {
            Text("קבל מיקום נוכחי")
        }

        Text(text = "בחר תמונת פרופיל", style = MaterialTheme.typography.bodyMedium)
        Button(onClick = { imagePickerLauncher.launch("image/*") }) {
            Text("בחר תמונה")
        }
        // הצגת תמונה נבחרת (אם קיימת)
        imageUri?.let { uri ->
            Image(
                painter = rememberAsyncImagePainter(model = uri),
                contentDescription = "תמונת פרופיל",
                modifier = Modifier
                    .size(120.dp)
                    .padding(top = 8.dp)
            )
        }
        // הודעת שגיאה עבור תמונה
        imageError?.let { Text(text = it, color = Color.Red) }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Checkbox(checked = autoLogin, onCheckedChange = { autoLogin = it })
            Text(text = "התחבר אוטומטית")
        }

        Button(onClick = {
            // ביצוע ולידציה לפני שליחה
            if (tempFirstName.isBlank()) firstNameError = "יש להזין שם פרטי"
            if (tempLastName.isBlank()) lastNameError = "יש להזין שם משפחה"
            if (tempAge.toIntOrNull() == null || tempAge.toInt() <= 0) ageError = "יש להזין גיל תקין"
            if (tempCoordinates.isBlank()) coordinatesError = "יש לשים כתובת"
            if (tempNickname.isBlank()) nicknameError = "יש להזין כינוי"

            // אם אין הודעות שגיאה, מעדכנים את הפרופיל
            if (firstNameError == null && lastNameError == null && ageError == null && coordinatesError == null) {
                userViewModel.updateUserProfile(
                    firstName = tempFirstName,
                    lastName = tempLastName,
                    age = tempAge.toInt(),
                    coordinates = tempCoordinates,
                    profileImageUrl = tempProfileImageUrl,
                    nickname = tempNickname
                ) { success ->
                    if (success) {
                        PreferencesHelper.setAutoLogin(context, autoLogin)
                        navigateToHome()
                    }
                }
            }
        }) {
            Text("שמירת פרופיל")
        }

        if (errorMessage != null) {
            Text(text = errorMessage!!, color = Color.Red)
        }
    }
}

@Composable
fun ValidatedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    error: String? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default
) {
    Column {
        TextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            keyboardOptions = keyboardOptions
        )
        error?.let {
            Text(text = it, color = Color.Red)
        }
    }
}


package com.example.soccergamesfinder.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.soccergamesfinder.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(
    authViewModel: AuthViewModel,
    navigateToCompleteProfile: () -> Unit
) {
    val email = remember { mutableStateOf("") }
    val password = remember { mutableStateOf("") }
    val errorMessage by authViewModel.errorMessage

    LaunchedEffect(authViewModel.user.value) {
        authViewModel.user.value?.let {
            navigateToCompleteProfile()
        }
    }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = email.value,
            onValueChange = { email.value = it },
            label = { Text("אימייל") }
        )
        TextField(
            value = password.value,
            onValueChange = { password.value = it },
            label = { Text("סיסמה") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Password),
            visualTransformation = PasswordVisualTransformation()
        )

        if (errorMessage != null) {
            Text(text = errorMessage!!, color = Color.Red)
        }

        Button(onClick = { authViewModel.register(email.value, password.value) }) {
            Text("הירשם")
        }
    }
}
